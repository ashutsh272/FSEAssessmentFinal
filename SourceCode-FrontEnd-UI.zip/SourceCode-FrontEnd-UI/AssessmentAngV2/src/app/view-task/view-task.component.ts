import { Component, OnInit } from '@angular/core';
import { Task } from '../models/Task';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})
export class ViewTaskComponent implements OnInit {

  viewTaskResponse: any = this.getAllTasks();
  taskList: Task[];
  searchInput:string;

  constructor(private http: HttpClient) { }

  ngOnInit() {
  }

  private sortTaskList(criteria: string) {
    console.log("sortProjectList: ");
    if (criteria == "SDATE") {
      this.taskList = this.taskList.sort((one, two) => (one.startDate > two.startDate ? 1 : -1));
    } else if (criteria == "EDATE") {
      this.taskList = this.taskList.sort((one, two) => (one.endDate > two.endDate ? 1 : -1));
    } else if (criteria == "PRIO") {
      this.taskList = this.taskList.sort((one, two) => (one.priority > two.priority ? 1 : -1));
    } else if (criteria == "COMP") {
      this.taskList = this.taskList.sort((one, two) => (one.status > two.status ? 1 : -1));
    }
  }

  private searchProjectTask(){
    if(this.searchInput !="") {
      this.taskList = this.taskList.filter(it => {
          return (it.projectName.toLowerCase().includes(this.searchInput.toLowerCase()));
        });
    } else {
      this.taskList = this.viewTaskResponse.taskList;
    }
    return this.taskList;
  }

  private getAllTasks() {
    console.log("getAllTasks");
    let obs = this.http.get('http://localhost:8080/projmanager/task/view/all');
    obs.subscribe(responseV => {
      this.viewTaskResponse = responseV;
      this.taskList = this.viewTaskResponse.taskList;
      console.log("Task List: " + this.taskList);
      console.log("First Task Name:: " + this.taskList[0].task);

    });
  }

}
