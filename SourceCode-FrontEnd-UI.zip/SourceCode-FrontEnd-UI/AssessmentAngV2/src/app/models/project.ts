export class Project {
    projectId: string ;
    projectName: string = '';
    priority: number = 0;
    startDate: string = '';
    endDate: string = '';
    userId: string = '';
    employeeId:string='';
    status: string = '';
    noOfTasks:number=0;
    completedTaskCount=0;

    constructor() { 
    }

    
}
