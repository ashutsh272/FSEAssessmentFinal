import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Project } from 'src/app/models/project';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-view-project',
  templateUrl: './view-project.component.html',
  styleUrls: ['./view-project.component.css']
})
export class ViewProjectComponent implements OnInit {

  @Input('projectinfo') projectObj:Project;
  /*@Output() notifyProjectDetail:EventEmitter<Project>=new EventEmitter<Project>();*/
  projectDetail:Project=new Project();
  editProjectFlag:boolean=false;
  updatedProject:Project;
  successMsg:string='';
  errorMsg:string='';
  response: any;


  constructor(private http:HttpClient) { }

  ngOnInit() {
    this.projectDetail.projectName=this.projectObj.projectName;
    this.projectDetail.priority=this.projectObj.priority;
    this.projectDetail.startDate=this.projectObj.startDate;
    this.projectDetail.endDate=this.projectObj.endDate;
    this.projectDetail.noOfTasks=this.projectObj.noOfTasks;
    this.projectDetail.completedTaskCount=this.projectObj.completedTaskCount;
  }

  

  editProject(){
    console.log("editProject");
    this.editProjectFlag=true;
  }

  updateProject(updatedProject:Project){
    /*this.notifyProjectDetail.emit(this.projectDetail);*/
    console.log("updateUser");
    this.updatedProject=updatedProject;
    this.postUserCall();
    this.editProjectFlag=false;
  }

  

  private postUserCall() {
    let obs = this.http.post('http://localhost:8080/projmanager/project/update', this.updatedProject, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    });
    obs.subscribe(response => {
      this.response = response;
      console.log(this.response);
      if (this.response.result.status == "ERROR") {
        this.errorMsg = this.response.result.errorInfo.desc;
      }else{
        this.successMsg = "User:" + this.updatedProject.projectName + " updated successfully. Refresh for updated view";
      }

    });
  }





}
