import { Component, OnInit } from '@angular/core';
import { Project } from '../models/project';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from '../models/user';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit {

  project: Project;
  viewProjectResponse: any = this.getAllProjects();
  projectList: Project[];
  managerList: User[];
  viewUserResponse: any = this.getAllUsers();
  validationFlag: boolean = false;
  response: any;
  successMsg: string;
  errorMsg: String;
  searchInput:string;
  enableSetDate:boolean=false;
  updateProjectDetail =false;

  constructor(private http: HttpClient, private datepipe: DatePipe) {
    this.project = new Project();
    this.getDefaultDate();
  }

  ngOnInit() {
  }

  /*updateProject(project:Project){
    this.project.projectName=project.projectName;
    this.project.employeeId=project.employeeId;
    this.updateProjectDetail=true;
  }*/

  getDefaultDate(){
        let date: Date = new Date(); 
        let latest_date =this.datepipe.transform(date, 'yyyy-MM-dd'); 
        this.project.startDate=latest_date;
        console.log("startDate: "+this.project.startDate);
        date.setDate(date.getDate()+1);
        let latest_date_next =this.datepipe.transform(date, 'yyyy-MM-dd');
        this.project.endDate=latest_date_next;
        console.log("endDate: "+this.project.endDate);
    }

  private addProject() {
    this.validationFlag = false;
    this.successMsg = null;
    this.errorMsg = null;
    console.log("addProject");
    if (this.project.projectName == null
      || this.project.priority == null
      || this.project.employeeId == null ||
      this.project.projectName == '' || this.project.employeeId == '') {
      this.resetAddProject();
      this.validationFlag = true;
      this.errorMsg = 'Mandatory fields missing';
    } else {
      this.postProjectCall();

    }
  }

  private postProjectCall() {
    let obs = this.http.post('http://localhost:8080/projmanager/project/add', this.project, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    });
    obs.subscribe(response => {
      this.response = response;
      console.log(this.response);
      this.successMsg = "Project: " + this.project.projectName + " saved successfully";
      if (this.response.result.status == "ERROR") {
        this.resetAddProject();
        this.validationFlag = true;
        this.errorMsg = this.response.result.errorInfo.desc;

      } else {
        this.successMsg = "Project:" + this.project.projectName + " saved successfully";
        this.viewProjectResponse = this.getAllProjects();
      }

    });
  }

  private resetAddProject() {
    this.project.projectName = null;
    this.project.priority = null;
    this.project.startDate = null;
    this.project.endDate = null;
    this.project.employeeId = null;
    this.successMsg = null;
    this.validationFlag = false;
    this.errorMsg = null;
    this.getDefaultDate();
    console.log("resetAddProject:" + this.project.projectName);
  }

  private setManager(manager: User) {
    this.project.userId = manager.userId;
    this.project.employeeId = manager.employeeId;
  }

  private enableDateInput(){
    this.enableSetDate=!this.enableSetDate;
  }

  enableEditProjectDetail(){
    this.updateProjectDetail=true;
  }

  private getAllUsers() {
    console.log("getAllUsers");
    let obs = this.http.get('http://localhost:8080/projmanager/user/view/all');
    obs.subscribe(responseV => {
      this.viewUserResponse = responseV;
      this.managerList = this.viewUserResponse.userList;
      console.log("User List: " + this.managerList);
      console.log("First User Name:: " + this.viewUserResponse.userList[1].firstName);

    });
  }

  private getAllProjects() {
    console.log("getAllProjects");
    let obs = this.http.get('http://localhost:8080/projmanager/project/view/all');
    obs.subscribe(responseV => {
      this.viewProjectResponse = responseV;
      this.projectList = this.viewProjectResponse.projectList;
      console.log("Project List: " + this.projectList);
      console.log("First Project Name:: " + this.viewProjectResponse.projectList[1].projetName);
      let convertedDate =this.datepipe.transform(this.viewProjectResponse.projectList[1].startDate, 'yyyy-MM-dd'); 
      console.log("First Project Start Date:: " + convertedDate);

    });
  }

  private searchProject(){
    if(this.searchInput !="") {
      this.projectList = this.projectList.filter(it => {
          return (it.projectName.toLowerCase().includes(this.searchInput.toLowerCase()));
        });
    } else {
      this.projectList = this.viewProjectResponse.projectList;
    }
    return this.projectList;
  }
  
  private sortProjectList(criteria: string) {
    console.log("sortProjectList: ");
    if (criteria == "SDATE") {
      this.projectList = this.projectList.sort((one, two) => (one.startDate > two.startDate ? 1 : -1));
    } else if (criteria == "EDATE") {
      this.projectList = this.projectList.sort((one, two) => (one.endDate > two.endDate ? 1 : -1));
    } else if (criteria == "PRIO") {
      this.projectList = this.projectList.sort((one, two) => (one.priority > two.priority ? 1 : -1));
    } else if (criteria == "COMP") {
      this.projectList = this.projectList.sort((one, two) => (one.completedTaskCount > two.completedTaskCount ? 1 : -1));
    }
  }

}
