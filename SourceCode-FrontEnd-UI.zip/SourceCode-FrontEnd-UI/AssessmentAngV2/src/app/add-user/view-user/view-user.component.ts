import { Component, OnInit, Input } from '@angular/core';
import { User } from 'src/app/models/user';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {

  @Input('userinfo') userObj: User;
  userDeatil:User;
  editUserFlag:boolean=false;
  upDatedUser:User;
  successMsg:string='';
  errorMsg:string='';
  response: any;

  constructor(private http:HttpClient) { 

  }

  ngOnInit() {
    this.userDeatil= {
      firstName:this.userObj.firstName,
      lastName:this.userObj.lastName,
      userId:this.userObj.userId,
      employeeId:this.userObj.employeeId
    }

  }

  editUser(){
    console.log("editUser");
    this.editUserFlag=true;
  }

  updateUser(upDatedUser:User){
    console.log("updateUser");
    this.upDatedUser=upDatedUser;
    this.postUserCall();
    this.editUserFlag=false;
  }

  private postUserCall() {
    let obs = this.http.post('http://localhost:8080/projmanager/user/update', this.upDatedUser, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    });
    obs.subscribe(response => {
      this.response = response;
      console.log(this.response);
      if (this.response.result.status == "ERROR") {
        this.errorMsg = this.response.result.errorInfo.desc;
      }else{
        this.successMsg = "User:" + this.upDatedUser.firstName + " updated successfully. Refresh for updated view";
      }

    });
  }

  deleteUser(toBeDeletedUser:User){
    let tempUserName=toBeDeletedUser.firstName;
    console.log("deleteUser");
    let obs = this.http.get('http://localhost:8080/projmanager/user/delete/'+toBeDeletedUser.userId);
    obs.subscribe(response => {
      this.response = response;
      console.log(this.response);
      if (this.response.result.status == "ERROR") {
        this.errorMsg = this.response.result.errorInfo.desc;
      }else{
        this.successMsg = "User:" + tempUserName + " deleted successfully. Refresh for updated view";
      }

    });
  }

}
