import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaderResponse, HttpHeaders } from '@angular/common/http';
import { User } from '../models/user';


@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  user: User;
  response: any;
  successMsg: string;
  errorMsg:String;
  validationFlag: boolean = false;
  viewUserResponse:any=this.getAllUsers();
  userList:User[];
  searchInput:string;

  constructor(private http: HttpClient) {
    this.user = new User();
  }

  ngOnInit() {
  }

  private searchUser() {
    if(this.searchInput !="") {
      this.userList = this.userList.filter(it => {
          return (it.firstName.toLowerCase().includes(this.searchInput.toLowerCase()) || it.lastName.toLowerCase().includes(this.searchInput.toLowerCase())
          || it.employeeId.toLowerCase().includes(this.searchInput.toLowerCase()));
        });
    } else {
      this.userList = this.viewUserResponse.userList;
    }
    return this.userList;
  }

  private getAllUsers(){
    console.log("getAllUsers");
    let obs = this.http.get('http://localhost:8080/projmanager/user/view/all');
    obs.subscribe(responseV=>{
      this.viewUserResponse=responseV;
      this.userList = this.viewUserResponse.userList;
      console.log("User List: " +this.userList);
      console.log("First User Name:: " +this.viewUserResponse.userList[1].firstName);
      
    }); 
  }

  private sortUserList(criteria:string){
    console.log("shortUserList: ");
    if(criteria=="FNAME"){
      this.userList=this.userList.sort((one, two) => (one.firstName > two.firstName ? 1 : -1));
    }else if(criteria=="LNAME"){
      this.userList=this.userList.sort((one, two) => (one.lastName > two.lastName ? 1 : -1));
    }else if(criteria=="EID"){
      this.userList=this.userList.sort((one, two) => (one.employeeId > two.employeeId ? 1 : -1));
    }
  }

  private resetAddUser() {
    this.user.firstName = null;
    this.user.lastName = null;
    this.user.employeeId = null;
    this.user.userId = null;
    this.successMsg=null;
    this.validationFlag = false;
    this.errorMsg=null;
    console.log("resetAddUser:" + this.user.firstName);
  }

  private addUser() {
    this.validationFlag = false;
    this.successMsg=null;
    this.errorMsg=null;
    console.log("addUser");
    if (this.user.firstName == null
      || this.user.lastName == null
      || this.user.employeeId == null ||
      this.user.firstName == '' || this.user.lastName == '' || this.user.employeeId == '') {
      this.resetAddUser();
      this.validationFlag = true;
      this.errorMsg = 'Mandatory fields missing';
    } else {
      this.postUserCall();

    }

  }

  private postUserCall() {
    let obs = this.http.post('http://localhost:8080/projmanager/user/add', this.user, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    });
    obs.subscribe(response => {
      this.response = response;
      console.log(this.response);
      this.successMsg = "User: " + this.user.firstName + " saved successfully";
      if (this.response.result.status == "ERROR") {
        this.resetAddUser();
        this.validationFlag = true;
        this.errorMsg = this.response.result.errorInfo.desc;
        
      }else{
        this.successMsg = "User:" + this.user.firstName + " saved successfully";
        this.viewUserResponse = this.getAllUsers();
      }

    });
  }

}
