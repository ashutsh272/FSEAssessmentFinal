import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Task } from '../models/Task';
import { Project } from '../models/project';
import { User } from '../models/user';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {

  task: Task;
  viewProjectResponse: any = this.getAllProjects();
  projectList: Project[];
  viewUserResponse: any = this.getAllUsers();
  userList: User[];
  viewParentResponse: any = this.getAllParentTasks();
  parentTaskList: Task[];
  parentFlag:boolean=false;
  validationFlag: boolean = false;
  response: any;
  successMsg: string;
  errorMsg: String;

  constructor(private http: HttpClient, private datepipe: DatePipe) { 
    this.task = new Task();
    this.getDefaultDate();
  }

  ngOnInit() {
  }

  enableParentFlag(){
    this.parentFlag=!this.parentFlag;
    this.task.parentTaskEnabled=!this.task.parentTaskEnabled;
  }

  private setProject(project: Project) {
    this.task.projectName = project.projectName;
    this.task.projectId = project.projectId;
  }

  private setParentTask(parentTask: Task) {
    this.task.parentTask = parentTask.task;
    this.task.parentTaskId = parentTask.taskId;
  }

  private setTaskOwner(taskOwner: User) {
    this.task.userEId = taskOwner.employeeId;
    this.task.userId = taskOwner.userId;
  }

  private getAllParentTasks() {
    console.log("getAllParentTasks");
    let obs = this.http.get('http://localhost:8080/projmanager/parenttask/view/all');
    obs.subscribe(responseV => {
      this.viewParentResponse = responseV;
      this.parentTaskList = this.viewParentResponse.taskList;
      console.log("ParentTask List: " + this.parentTaskList);
      console.log("First Parent task Name:: " + this.parentTaskList[0].task);

    });
  }

  private getAllUsers() {
    console.log("getAllUsers");
    let obs = this.http.get('http://localhost:8080/projmanager/user/view/all');
    obs.subscribe(responseV => {
      this.viewUserResponse = responseV;
      this.userList = this.viewUserResponse.userList;
      console.log("User List: " + this.userList);
      console.log("First User Name:: " + this.viewUserResponse.userList[1].firstName);

    });
  }

  private getAllProjects() {
    console.log("getAllProjects");
    let obs = this.http.get('http://localhost:8080/projmanager/project/view/all');
    obs.subscribe(responseV => {
      this.viewProjectResponse = responseV;
      this.projectList = this.viewProjectResponse.projectList;
      console.log("Project List: " + this.projectList);
      console.log("First Project Name:: " + this.viewProjectResponse.projectList[1].projetName);

    });
  }

  private resetAddTask() {
    this.task.task = null;
    this.task.priority = null;
    this.task.startDate = null;
    this.task.endDate = null;
    this.task.userId = null;
    this.task.userEId = null;
    this.task.parentTaskId=null;
    this.task.parentTask=null;
    this.task.projectId=null;
    this.task.projectName=null;
    this.successMsg = null;
    this.validationFlag = false;
    this.errorMsg = null;
    this.getDefaultDate();
    console.log("resetAddTask:" + this.task.task);
  }
  
  private addTask() {
    this.validationFlag = false;
    this.successMsg = null;
    this.errorMsg = null;
    console.log("addTask");
    if(this.parentFlag){
      if(this.task.task == null|| this.task.task ==''){
        this.resetAddTask();
        this.validationFlag = true;
        this.errorMsg = 'Mandatory fields missing';
      }else {
        this.postTaskCall();
  
      }
    }else{
      if (this.task.task == null
        || this.task.priority == null
        || this.task.userId == null ||this.task.parentTaskId == null||this.task.projectId==null||
        this.task.task == ''||
        this.task.userId == '' ||this.task.parentTaskId == ''||this.task.projectId==''
        ) {
        this.resetAddTask();
        this.validationFlag = true;
        this.errorMsg = 'Mandatory fields missing';
      } else {
        this.postTaskCall();
  
      }
    }
    
  }

  private postTaskCall() {
    let obs = this.http.post('http://localhost:8080/projmanager/task/add', this.task, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    });
    obs.subscribe(response => {
      this.response = response;
      console.log(this.response);
      this.successMsg = "Task: " + this.task.task + " saved successfully";
      if (this.response.result.status == "ERROR") {
        this.resetAddTask();
        this.validationFlag = true;
        this.errorMsg = this.response.result.errorInfo.desc;

      } else {
        this.successMsg = "Task:" + this.task.task + " saved successfully";
      }

    });
  }

  getDefaultDate(){
    let date: Date = new Date(); 
    let latest_date =this.datepipe.transform(date, 'yyyy-MM-dd'); 
    this.task.startDate=latest_date;
    console.log("startDate: "+this.task.startDate);
    date.setDate(date.getDate()+1);
    let latest_date_next =this.datepipe.transform(date, 'yyyy-MM-dd');
    this.task.endDate=latest_date_next;
    console.log("endDate: "+this.task.endDate);
}

}
